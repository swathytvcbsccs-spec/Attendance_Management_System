# Student Attendance Management System

Open `index.html` in any browser (Chrome/Edge/Firefox). No installation needed.

## Structure
- 4 Departments: BCA, MCA, BBA, MBA
- 4 HODs, 20 Mentors (5 per dept, 1 subject each)
- 8 Sections (A, B per dept), 120 Students (15 per section)

## Demo Logins
| Role | Email | Password |
|---|---|---|
| Administrator | admin@ams.com | admin123 |
| HOD | hod.bca@ams.com | hod123 |
| Mentor | mentor1.bca@ams.com | mentor123 |
| Student | bca.a01@ams.com | BCA-A01 (default = Roll No) |

Pattern: hod.mca@ams.com, mentor3.bba@ams.com, mba.b15@ams.com

## Note
Data is stored in the browser (localStorage). For real deployment, connect a backend (PHP+MySQL / Node+MongoDB).
